#include "LinkedList.h"

LinkedList::LinkedList()
{
    //ctor
}

LinkedList::~LinkedList()
{
    //dtor
}
